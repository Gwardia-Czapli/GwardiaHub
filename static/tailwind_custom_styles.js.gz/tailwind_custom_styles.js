// Used for custom styles in templates

tailwind.config = {
      theme: {
        extend: {
          borderWidth: {
            '12': '12px',
          },
        },
      },
}